## 2\. ADR-001: Linux PTY-Based Hardware Simulation (adr-001-gps-simulation.md)

* **Status:** Accepted  
* **Date:** Sprint 1

### Context

Laboratory environments are unsuitable for real-world GPS signal testing due to indoor attenuation and the non-deterministic nature of live satellite feeds. Verification of parsing logic and state machine transitions requires a controlled, reproducible data stream.

### Decision

The system will utilize **Linux Pseudo-terminals (PTY)** via pty.openpty() as a drop-in hardware replacement. gps\_double.py will serve as the PTY master, streaming deterministic NMEA data at exactly **1Hz** to mimic real-world hardware behavior.

### Rationale

The "So What?" factor: PTY allows pyserial to interface with a virtual port (e.g., /dev/pts/N) without modifying a single line of client code. The implementation developed for the simulation is identical to the implementation used for flight hardware. To ensure automation, the simulator must output the slave port path to stdout, allowing the client or test suite to connect dynamically. This strategy reduces hardware lead time to zero and ensures the software suite is fully vetted before physical integration.


