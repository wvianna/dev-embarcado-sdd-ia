## 4\. Implementation Plan (plan.md)

We employ the "Double" design pattern, developing a high-fidelity simulator and the implementation client in parallel. This creates a closed-loop environment where verification is continuous.

| Component | Role | Dependencies | Primary Responsibilities |
| :---- | :---- | :---- | :---- |
| **gps\_double.py** | Hardware Simulator | os, pty, time | • Create PTY master/slave pair. • Broadcast slave path to stdout. • Stream $GPGGA at deterministic 1Hz frequency. |
| **gps\_client.py** | System Implementation | pyserial, csv, time | • Connect to dynamic PTY slave port. • Enforce 9600 8N1 and 500ms SyncError timeout. • Execute state transitions and log parsed data. |

