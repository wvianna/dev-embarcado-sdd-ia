import unittest

from gps.gps_client import calculate_checksum, parse_gpgga


class TestGpsParser(unittest.TestCase):
    def test_valid_gpgga_parsing(self):
        # Checksum *52 is the correct XOR for this sentence body.
        sample = "$GPGGA,123519,5107.000,N,11402.000,W,1,08,0.9,545.4,M,46.9,M,,*52"
        latitude, longitude = parse_gpgga(sample)
        self.assertEqual(latitude, "5107.000")
        self.assertEqual(longitude, "11402.000")

    def test_checksum_failure(self):
        corrupted = "$GPGGA,123519,5107.000,N,11402.000,W,1,08,0.9,545.4,M,46.9,M,,*99"
        with self.assertRaises(ValueError):
            parse_gpgga(corrupted)

    def test_unsupported_sentence_type(self):
        sentence = "$GPRMC,123519,A,4807.038,N,01131.000,E,022.4,084.4,230394,003.1,W*6A"
        with self.assertRaises(ValueError):
            parse_gpgga(sentence)

    def test_checksum_calculation(self):
        body = "GPGGA,123519,5107.000,N,11402.000,W,1,08,0.9,545.4,M,46.9,M,,"
        self.assertEqual(calculate_checksum(body), "52")


if __name__ == "__main__":
    unittest.main()
