## 5\. Task Decomposition (tasks.md)

### Stage 1: Environment & Simulator (Priority: High)

* Task 1.1: Initialize Python 3.10 venv and install pyserial.  
* Task 1.2: Implement gps\_double.py PTY master/slave creation and slave path broadcast.  
* Task 1.3: Implement 1Hz deterministic streaming loop in gps\_double.py with valid NMEA sentences.

### Stage 2: Serial Connection & State Control (Priority: High)

* Task 2.1: Implement gps\_client.py UART connection logic (9600 8N1).  
* Task 2.2: Implement 500ms timeout logic triggering a SyncError exception.  
* Task 2.3: Implement INIT \-\> STANDBY automatic transition logic.

### Stage 3: Application Logic (Priority: Medium)

* Task 3.1a: Implement NMEA checksum verification logic for $GPGGA.  
* Task 3.1b: Implement Latitude (Index 2\) and Longitude (Index 4\) extraction.  
* Task 3.2: Implement SCIENCE state loop for continuous reading and CSV logging.


