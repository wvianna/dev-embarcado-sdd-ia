# Sprint 1 Software Design Document (SDD) & Implementation Package: GPS Telemetry System

## 1\. Project Constitution (constitution.md)

In the development of mission-critical aerospace systems, the establishment of a "Constitution" is a strategic necessity that transcends simple coding standards. For a high-reliability GPS telemetry system, standardizing bit-level communication protocols and deterministic timing is the primary defense against systemic failure. By defining these "Absolute Truths" before implementation, we ensure that the software remains resilient under high-rate data acquisition and that the "Contract" between hardware and software is never breached.

### Tech Stack

* **Language:** Python 3.10+  
* **Core Library:** pyserial (The mandated medium for UART communication).  
* **Environment:** Isolated virtual environment (venv) to prevent dependency drift.

### Architecture Rules (Absolute Truths)

1. **1\. Byte and Bit Order:** To maintain strict compliance with Req: FPX-SW-0015 / GPS-SW-0015, data transmission must follow **Little Endian** byte order (Least Significant byte first). Crucially, the **Least Significant Bit (LSB) of every byte must be sent first**, followed by the MS byte.  
2. **2\. Timing & Reliability:** Serial read operations must enforce a **deterministic 500ms timeout** (Req: GPS-SW-0270). Any violation of this timing window must immediately trigger a **SyncError** to prevent infinite blocking and maintain system control.  
3. **3\. Hardware Interface:** The interface is mandated as **UART 9600 8N1** (9600 baud, 8-bit data, No parity, 1 stop bit) per Req: GPS-E-0210.

### Technical Note: Encoding Synthesis

While the UART transmission layer follows the Little Endian and LSB-first bit-ordering requirements of the FIPEX ICD, the payload itself (NMEA $GPGGA sentences) is ASCII-encoded. This design maintains architectural alignment with binary packet standards while allowing the use of standard text-based GPS strings for telemetry extraction.


