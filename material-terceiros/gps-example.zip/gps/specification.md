## 3\. Interface and Functional Specification (specification.md)

### 1\. Interface Logic

* **Connection:** Dynamic connection to the PTY slave port provided by the simulator.  
* **Configuration:** Fixed 9600 8N1 serial parameters.  
* **Safety:** 500ms packet-level timeout leading to a SyncError.

### 2\. State Machine

* **INIT:** Hardware/UART initialization. Upon successful setup, the system **automatically transitions** to STANDBY.  
* **STANDBY:** Idle state. PTY connection is verified, but no data parsing or logging occurs.  
* **SCIENCE:** High-rate data acquisition triggered by the system control loop. Continuously captures and parses serial data.  
* **ERROR:** Entered upon a SyncError (500ms timeout) or data corruption. Aborts active CSV writes and resets to a safe state.

### 3\. Data Parsing ($GPGGA)

* **Validation:** Every sentence must pass NMEA checksum verification (XOR of all characters between $ and \*).  
* **Field Mapping:**  
  * **Latitude:** Index 2 (The 3rd element in the comma-separated string).  
  * **Longitude:** Index 4 (The 5th element in the comma-separated string).  
* **Logging:** Validated coordinates and system timestamps are appended to telemetry.csv.


