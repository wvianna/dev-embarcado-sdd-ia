# gps package initializer
