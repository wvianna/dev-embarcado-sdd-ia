#!/usr/bin/env python3
"""GPS telemetry client for NMEA $GPGGA sentences.

State machine: INIT -> STANDBY -> SCIENCE -> ERROR
Enforces 9600 8N1 serial configuration and a 500 ms packet-level timeout
(SyncError) per the SDD constitution (Req GPS-SW-0270, GPS-E-0210).
Parsed coordinates and timestamps are logged to telemetry.csv.
"""
import argparse
import csv
import os
import time
from datetime import datetime, timezone

import serial


class SyncError(Exception):
    """Raised when the 500 ms packet-level timeout is exceeded."""


def calculate_checksum(sentence: str) -> str:
    """Compute the NMEA XOR checksum for the sentence body (without leading '$')."""
    checksum = 0
    for ch in sentence:
        checksum ^= ord(ch)
    return f"{checksum:02X}"


def parse_gpgga(sentence: str) -> tuple[str, str]:
    """Validate an NMEA $GPGGA sentence and extract latitude and longitude.

    Args:
        sentence: Raw NMEA string including leading '$' and '*HH' checksum.

    Returns:
        (latitude, longitude) as strings (e.g. ('5107.000', '11402.000')).

    Raises:
        ValueError: If the checksum is invalid or the sentence is not GPGGA.
    """
    raw = sentence.strip()
    if not raw.startswith("$"):
        raise ValueError("Sentence must start with '$'.")
    if "*" not in raw:
        raise ValueError("Sentence missing checksum separator '*'.")

    body, checksum_text = raw[1:].split("*", 1)
    if len(checksum_text) < 2:
        raise ValueError("Checksum must be two hex digits.")

    expected = calculate_checksum(body)
    received = checksum_text[:2].upper()
    if received != expected:
        raise ValueError(f"Invalid checksum: expected {expected}, got {received}.")

    fields = body.split(",")
    if fields[0] != "GPGGA":
        raise ValueError("Unsupported NMEA sentence type.")
    if len(fields) <= 4:
        raise ValueError("Incomplete GPGGA sentence.")

    return fields[2], fields[4]  # latitude (index 2), longitude (index 4)


def read_sentence(serial_port: serial.Serial, packet_timeout: float = 0.5,
                  start_timeout: float = 2.0) -> str:
    """Read one NMEA sentence from the serial port.

    Waits up to *start_timeout* seconds for the first byte, then enforces
    *packet_timeout* seconds for the remainder of the sentence.

    Raises:
        SyncError: If the packet-level deadline is exceeded (Req GPS-SW-0270).
    """
    original_timeout = serial_port.timeout
    try:
        buffer = bytearray()

        # Wider window for the first byte (line may arrive just after open).
        serial_port.timeout = start_timeout
        first_byte = serial_port.read(1)
        if not first_byte:
            raise SyncError("No data received from serial port.")
        buffer.extend(first_byte)

        deadline = time.time() + packet_timeout
        while True:
            remaining = deadline - time.time()
            if remaining <= 0:
                raise SyncError("Packet timeout waiting for complete sentence.")
            serial_port.timeout = remaining
            next_byte = serial_port.read(1)
            if not next_byte:
                continue
            buffer.extend(next_byte)
            if next_byte == b"\n":
                break

        return buffer.decode("ascii", errors="ignore").strip()
    finally:
        serial_port.timeout = original_timeout


class GpsClient:
    """State machine implementation: INIT -> STANDBY -> SCIENCE -> ERROR."""

    STATE_INIT = "INIT"
    STATE_STANDBY = "STANDBY"
    STATE_SCIENCE = "SCIENCE"
    STATE_ERROR = "ERROR"

    def __init__(self, port: str, baudrate: int = 9600, timeout: float = 0.5):
        self.port = port
        self.baudrate = baudrate
        self.timeout = timeout
        self.state = self.STATE_INIT
        self.serial_port: serial.Serial | None = None
        # Telemetry file is always created next to this module for consistency.
        self.telemetry_file = os.path.join(os.path.dirname(__file__), "telemetry.csv")

    def _set_state(self, new_state: str) -> None:
        self.state = new_state
        print(f"STATE={new_state}")

    def initialize(self) -> None:
        """Open the serial port (9600 8N1) and transition INIT -> STANDBY."""
        self._set_state(self.STATE_INIT)
        self.serial_port = serial.Serial(
            port=self.port,
            baudrate=self.baudrate,
            bytesize=serial.EIGHTBITS,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            timeout=self.timeout,
        )
        if not self.serial_port.is_open:
            self.serial_port.open()
        self.serial_port.reset_input_buffer()
        self._set_state(self.STATE_STANDBY)

    def run(self) -> int:
        """Entry point: initialize then enter the SCIENCE acquisition loop."""
        try:
            self.initialize()
            self._set_state(self.STATE_SCIENCE)
            self.science_loop()
        except (SyncError, ValueError, serial.SerialException) as exc:
            return self._handle_error(exc)
        except KeyboardInterrupt:
            print("Interrupted by user.")
            return 0
        return 0

    def science_loop(self) -> None:
        """Continuously read, parse, and log $GPGGA sentences to telemetry.csv."""
        fieldnames = ["timestamp", "latitude", "longitude"]
        write_header = (
            not os.path.exists(self.telemetry_file)
            or os.path.getsize(self.telemetry_file) == 0
        )

        with open(self.telemetry_file, "a", newline="", encoding="utf-8") as file_obj:
            writer = csv.DictWriter(file_obj, fieldnames=fieldnames)
            if write_header:
                writer.writeheader()

            while True:
                sentence = read_sentence(self.serial_port, packet_timeout=self.timeout)
                latitude, longitude = parse_gpgga(sentence)
                writer.writerow({
                    "timestamp": datetime.now(timezone.utc)
                    .replace(microsecond=0)
                    .isoformat()
                    .replace("+00:00", "Z"),
                    "latitude": latitude,
                    "longitude": longitude,
                })
                file_obj.flush()

    def _handle_error(self, exc: Exception) -> int:
        self._set_state(self.STATE_ERROR)
        print(f"ERROR: {exc}")
        return 1


def main() -> int:
    parser = argparse.ArgumentParser(
        description="GPS telemetry client for NMEA $GPGGA sentences."
    )
    parser.add_argument("port", help="Serial port path (e.g. /dev/pts/3).")
    args = parser.parse_args()
    return GpsClient(args.port).run()


if __name__ == "__main__":
    raise SystemExit(main())
