## 6\. Automated Testing Artifacts

### Artifact 1: test\_parser.py (Unit Test)

```py
import unittest
from gps_client import parse_gpgga

class TestGpsParser(unittest.TestCase):
    def test_valid_gpgga_parsing(self):
        # NMEA $GPGGA: Lat is 3rd element (index 2), Lon is 5th element (index 4)
        # Checksum *47 is valid for this string
        sample = "$GPGGA,123519,5107.000,N,11402.000,W,1,08,0.9,545.4,M,46.9,M,,*47"
        # Test extraction logic
        lat, lon = parse_gpgga(sample)
        self.assertEqual(lat, "5107.000")
        self.assertEqual(lon, "11402.000")

    def test_checksum_failure(self):
        # Intentionally corrupted checksum
        corrupted = "$GPGGA,123519,5107.000,N,11402.000,W,1,08,0.9,545.4,M,46.9,M,,*99"
        with self.assertRaises(ValueError):
            # Parser should raise error on checksum fail
            parse_gpgga(corrupted)

if __name__ == '__main__':
    unittest.main()
```

### Artifact 2: test\_integration.py (Integration Test)

```py
import unittest
import os
import time
import subprocess
import signal

class TestGpsIntegration(unittest.TestCase):
    def test_closed_loop_logging(self):
        # 1. Start Simulator as a subprocess
        sim_proc = subprocess.Popen(
            ['python3', 'gps_double.py'],
            stdout=subprocess.PIPE,
            text=True,
            preexec_fn=os.setsid
        )
        # 2. Capture the slave port from simulator stdout
        try:
            slave_port = sim_proc.stdout.readline().strip()
            self.assertTrue(slave_port.startswith('/dev/pts/'))
            # 3. Cleanup and Run Client for a fixed duration
            if os.path.exists("telemetry.csv"):
                os.remove("telemetry.csv")
            # Run client as a subprocess targeting the slave port
            client_proc = subprocess.Popen(['python3', 'gps_client.py', slave_port])
            time.sleep(3) # Allow time for at least 2 NMEA sentences (1Hz)
            client_proc.terminate()
            # 4. Verification
            self.assertTrue(os.path.exists("telemetry.csv"))
            with open("telemetry.csv", "r") as f:
```

```py
                content = f.readlines()
                self.assertGreater(len(content), 0, "Telemetry file is empty")
        finally:
            # Cleanup process group
            os.killpg(os.getpgid(sim_proc.pid), signal.SIGTERM)

if __name__ == '__main__':
    unittest.main()
```

