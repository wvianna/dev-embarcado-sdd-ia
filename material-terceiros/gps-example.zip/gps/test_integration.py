import os
import signal
import subprocess
import sys
import time
import unittest


class TestGpsIntegration(unittest.TestCase):
    def test_closed_loop_logging(self):
        # 1. Start the simulator subprocess; it prints the PTY slave path to stdout.
        sim_proc = subprocess.Popen(
            [sys.executable, "gps/gps_double.py"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            preexec_fn=os.setsid,
        )

        try:
            slave_port = sim_proc.stdout.readline().strip()
            self.assertTrue(slave_port.startswith("/dev/pts/"),
                            "Simulator did not emit a PTY path")

            # 2. Remove any leftover telemetry file before the run.
            telemetry_path = "gps/telemetry.csv"
            if os.path.exists(telemetry_path):
                os.remove(telemetry_path)

            # 3. Start the client targeting the slave port.
            client_proc = subprocess.Popen(
                [sys.executable, "gps/gps_client.py", slave_port],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                preexec_fn=os.setsid,
            )

            # Allow at least 2 NMEA sentences (1 Hz) to be logged.
            time.sleep(3)
            client_proc.terminate()
            client_proc.wait(timeout=5)

            # 4. Verify telemetry was created and contains data rows.
            self.assertTrue(os.path.exists(telemetry_path),
                            "Telemetry file was not created")
            with open(telemetry_path, "r", encoding="utf-8") as f:
                content = [line.strip() for line in f if line.strip()]
            self.assertGreater(len(content), 1, "Telemetry file does not contain logged data")
            self.assertEqual(content[0], "timestamp,latitude,longitude")
        finally:
            try:
                os.killpg(os.getpgid(sim_proc.pid), signal.SIGTERM)
            except Exception:
                pass


if __name__ == "__main__":
    unittest.main()
