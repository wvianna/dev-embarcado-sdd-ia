#!/usr/bin/env python3
"""GPS hardware simulator using a Linux PTY master/slave pair.

Streams valid $GPGGA NMEA sentences at 1 Hz to the PTY master.
Prints the slave port path to stdout so clients can connect dynamically.
"""
import os
import pty
import time
from datetime import datetime, timezone


def calculate_checksum(sentence: str) -> str:
    """Compute the NMEA XOR checksum for the sentence body (without leading '$')."""
    checksum = 0
    for ch in sentence:
        checksum ^= ord(ch)
    return f"{checksum:02X}"


def make_gpgga_sentence(latitude: str, lat_dir: str, longitude: str, lon_dir: str) -> str:
    """Build a complete, checksummed $GPGGA NMEA sentence."""
    utc_time = datetime.now(timezone.utc).strftime("%H%M%S")
    fields = [
        "GPGGA",
        utc_time,
        latitude,
        lat_dir,
        longitude,
        lon_dir,
        "1",    # fix quality
        "08",   # satellites tracked
        "0.9",  # horizontal dilution
        "545.4",
        "M",    # altitude unit
        "46.9",
        "M",    # geoid separation unit
        "",
        "",
    ]
    body = ",".join(fields)
    checksum = calculate_checksum(body)
    return f"${body}*{checksum}\r\n"


def main() -> None:
    master_fd, slave_fd = pty.openpty()
    slave_name = os.ttyname(slave_fd)
    # Broadcast slave path so clients / tests can connect dynamically.
    print(slave_name, flush=True)

    try:
        while True:
            sentence = make_gpgga_sentence("5107.000", "N", "11402.000", "W")
            os.write(master_fd, sentence.encode("ascii"))
            time.sleep(1.0)
    except KeyboardInterrupt:
        pass
    finally:
        os.close(master_fd)
        os.close(slave_fd)


if __name__ == "__main__":
    main()
